# Mi primer sitio web simple con HTML 5

Sitio "About me" de Adrian Alejandro Salinas Candelario.

- `index.html`: Curriculum Vitae
- `estudios.html`: Estudios
- `intereses.html`: Intereses y Hobbies
- `css/styles.css`: estilos
